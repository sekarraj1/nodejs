<?php
$name = $_POST['name'];
$email = $_POST['email'];
$phn= $_POST['phn'];
$queries = $_POST['queries'];
$message = $_POST['message'];

$m1 = "<h2>Quick Contact Request</h2><br><hr><br><b>Name : &nbsp;</b>".$name."<br>";
$m2 = "<b>E-mail : &nbsp;</b>".$email."<br>";
$m3 = "<b>Phone number : &nbsp;</b>".$phn."<br>";
$m4 = "<b>Queries : &nbsp;</b>".$queries."<br>";
$m5 = "<b>message : &nbsp;</b>".$message."<br>";

$message = $m1.$m2.$m3.$m4.$m5;

//define the receiver of the email
$to='rsekarraj.ece@gmail.com ';
$subject = 'Quick contact request From A1powersolutions';
$message = $m1.$m2.$m3.$m4.$m5;
$headers = "From: rsekarraj.ece@gmail\nContent-Type: text/html; charset=iso-8859-1\r\nReply-To: a1powersolutions";
$mail_sent = @mail( $to, $subject, $message, $headers );
//echo $mail_sent ? "Mail sent" : "Mail failed";
header('Location: contact.html');

?>